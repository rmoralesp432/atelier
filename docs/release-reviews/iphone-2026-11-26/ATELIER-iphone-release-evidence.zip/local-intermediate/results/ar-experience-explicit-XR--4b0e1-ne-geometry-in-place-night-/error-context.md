# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ar-experience.spec.ts >> explicit XR transport fixture hosts shared AI conversation and refreshes genuine geometry in place (night)
- Location: tests/ar-experience.spec.ts:181:3

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator: getByRole('textbox', { name: 'Message Atelier' })
Expected: "A draft to continue later"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toHaveValue" getByRole('textbox', { name: 'Message Atelier' }) with timeout 15000ms
  - waiting for getByRole('textbox', { name: 'Message Atelier' })

```

```yaml
- banner:
  - link "ATELIER home":
    - /url: ./
  - button "Projects": Untitled study
  - button "Explore design"
- main:
  - region "Modeling workspace":
    - combobox "Camera view":
      - option "Perspective" [selected]
      - option "Orthographic"
      - option "Top view"
    - button "Appearance"
    - text: ↑ Project N
    - textbox "Selected object color": "#e2e7e6"
    - button "Edit selected dimensions":
      - text: Main pavilion
      - strong: 14 × 9 × 5 m
    - button "Selected object actions"
    - toolbar "Modeling tools":
      - toolbar "Touch navigation":
        - button "Touch orbit" [pressed]
        - button "Touch pan"
        - button "Touch edit"
      - button "Frame all"
    - button "Voice orb"
    - status: Atelier
    - navigation "Workspace actions":
      - button "Show objects": Objects
      - button "Create a 3D shape": Create
      - button "Open chat": Chat
      - button "Design tools": Tools
- contentinfo:
  - text: 2 volumes 1 selected
  - button "Undo"
  - button "Redo" [disabled]
```

# Test source

```ts
  239 |     await page
  240 |       .getByRole('button', { name: 'Open real AR', exact: true })
  241 |       .click();
  242 |     const overlay = page.locator('.ar-overlay');
  243 |     await expect(overlay).toBeVisible();
  244 |     await overlay
  245 |       .getByRole('button', { name: 'Placement', exact: true })
  246 |       .click();
  247 |     await overlay.getByRole('button', { name: 'Chat', exact: true }).click();
  248 |     await expect(
  249 |       page.getByRole('region', { name: 'View in your space' }),
  250 |     ).toBeHidden();
  251 |     await expect(
  252 |       overlay.getByRole('button', { name: 'Bring in front of me' }),
  253 |     ).toBeVisible();
  254 |     await expect(
  255 |       overlay.getByRole('textbox', { name: 'Message Atelier' }),
  256 |     ).toBeVisible();
  257 |     await expect(
  258 |       overlay.getByRole('textbox', { name: 'Message Atelier' }),
  259 |     ).toHaveCSS(
  260 |       'color',
  261 |       theme === 'day' ? 'rgb(39, 52, 46)' : 'rgb(245, 245, 247)',
  262 |     );
  263 |     await expect(
  264 |       overlay.getByRole('button', { name: 'Start voice conversation' }),
  265 |     ).toBeDisabled();
  266 |     expect(await page.locator('.conversation-area').count()).toBe(1);
  267 |     await overlay.getByText('Size & placement', { exact: false }).click();
  268 |     await expect(overlay.getByLabel('Live AR scale')).toBeDisabled();
  269 |     await overlay
  270 |       .getByRole('button', { name: 'Change scale', exact: true })
  271 |       .click();
  272 |     await overlay.getByLabel('Live AR scale').selectOption('1');
  273 |     await expect
  274 |       .poll(() => page.evaluate(() => (window as any).__xrFixture.scale))
  275 |       .toBe(1);
  276 |     await overlay
  277 |       .getByRole('button', { name: 'Confirm scale', exact: false })
  278 |       .click();
  279 |     await expect(overlay.getByLabel('Fine AR scale')).toBeDisabled();
  280 |     await overlay.getByRole('button', { name: 'Bring in front of me' }).click();
  281 |     await overlay
  282 |       .getByRole('button', { name: 'Rotate AR 5 degrees', exact: true })
  283 |       .click();
  284 |     await overlay.getByLabel('AR move increment').selectOption('1');
  285 |     await overlay.getByRole('button', { name: 'Closer', exact: true }).click();
  286 |     expect(
  287 |       await page.evaluate(() => {
  288 |         const f = (window as any).__xrFixture;
  289 |         return [f.front, f.rotation, f.move];
  290 |       }),
  291 |     ).toEqual([true, 5, [0, -1]]);
  292 |     await overlay
  293 |       .getByRole('button', { name: 'Change scale', exact: true })
  294 |       .click();
  295 |     await overlay
  296 |       .getByRole('button', { name: 'Fit width between two points' })
  297 |       .click();
  298 |     await expect(overlay.getByLabel('Live AR scale')).toHaveValue('0.1');
  299 |     await expect(
  300 |       overlay.getByRole('button', { name: 'Confirm scale', exact: false }),
  301 |     ).toBeVisible();
  302 |     await overlay
  303 |       .getByRole('button', { name: 'Life size · 1:1', exact: true })
  304 |       .click();
  305 |     await overlay
  306 |       .getByRole('button', { name: 'Confirm scale', exact: false })
  307 |       .click();
  308 |     await page.screenshot({
  309 |       path: `test-results/atelier-ar-placement-${theme}.png`,
  310 |     });
  311 |     await overlay.getByText('Size & placement', { exact: false }).click();
  312 |     await overlay
  313 |       .getByRole('textbox', { name: 'Message Atelier' })
  314 |       .fill('Move this two meters right');
  315 |     await overlay
  316 |       .getByRole('button', { name: 'Send message', exact: true })
  317 |       .click();
  318 |     await expect
  319 |       .poll(() => page.evaluate(() => (window as any).__xrFixture.updates))
  320 |       .toBe(1);
  321 |     const after = await saved(page);
  322 |     expect(after.project.volumes[0].position.z).toBe(
  323 |       before.project.volumes[0].position.z + 2,
  324 |     );
  325 |     expect(after.project.volumes[0].dimensions).toEqual(
  326 |       before.project.volumes[0].dimensions,
  327 |     );
  328 |     await expect
  329 |       .poll(() => page.evaluate(() => (window as any).__xrFixture.scale))
  330 |       .toBe(1);
  331 |     await overlay
  332 |       .getByRole('textbox', { name: 'Message Atelier' })
  333 |       .fill('A draft to continue later');
  334 |     await overlay.getByRole('button', { name: 'Exit AR', exact: true }).click();
  335 |     await expect(overlay).toBeHidden();
  336 |     await page.getByRole('button', { name: 'Close AR', exact: true }).click();
  337 |     await expect(
  338 |       page.getByRole('textbox', { name: 'Message Atelier' }),
> 339 |     ).toHaveValue('A draft to continue later');
      |       ^ Error: expect(locator).toHaveValue(expected) failed
  340 |     await expect(page.locator('.conversation-area')).toHaveCount(1);
  341 |   });
  342 | 
```