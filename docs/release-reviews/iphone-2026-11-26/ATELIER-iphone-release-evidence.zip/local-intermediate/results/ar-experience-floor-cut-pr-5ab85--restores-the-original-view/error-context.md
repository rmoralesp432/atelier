# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ar-experience.spec.ts >> floor cut previews in the workspace, prepares real cut geometry and restores the original view
- Location: tests/ar-experience.spec.ts:84:1

# Error details

```
Test timeout of 120000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "ATELIER home" [ref=e5] [cursor=pointer]:
      - /url: ./
    - button "Projects" [ref=e8] [cursor=pointer]:
      - generic [ref=e9]: Untitled study
    - button "Explore design" [ref=e10] [cursor=pointer]
  - main [ref=e14]:
    - region "Modeling workspace" [ref=e15]:
      - combobox "Camera view" [ref=e17]:
        - option "Perspective" [selected]
        - option "Orthographic"
        - option "Top view"
      - generic [ref=e18]:
        - button "Appearance" [ref=e19] [cursor=pointer]
        - region "View in your space" [ref=e23]:
          - button "Move AR panel" [ref=e24]:
            - strong [ref=e25]: View in your space
            - button "Close AR" [ref=e28] [cursor=pointer]
          - generic [ref=e32]:
            - generic [ref=e33]:
              - text: AR starts at 4.00 m
              - slider "Preview AR floor level" [active] [ref=e34]: "4"
            - generic [ref=e35]:
              - button "Show whole model" [ref=e36] [cursor=pointer]
              - button "Back to AR setup" [ref=e37] [cursor=pointer]
        - generic "Project north":
          - generic: ↑
          - generic: Project N
        - generic "Interactive 3D modeling viewport" [ref=e39]
      - generic "Atelier voice companion" [ref=e40]:
        - button "Voice orb" [ref=e41] [cursor=pointer]
        - status [ref=e43]: Atelier
      - navigation "Workspace actions" [ref=e44]:
        - button "Show objects" [ref=e45] [cursor=pointer]:
          - generic [ref=e50]: Objects
        - button "Create a 3D shape" [ref=e51] [cursor=pointer]:
          - generic [ref=e53]: Create
        - button "Open chat" [ref=e54] [cursor=pointer]:
          - generic [ref=e57]: Chat
        - button "Design tools" [ref=e58] [cursor=pointer]:
          - generic [ref=e62]: Tools
  - contentinfo:
    - generic [ref=e63]:
      - button "Undo" [disabled] [ref=e64]
      - button "Redo" [disabled] [ref=e68]
```