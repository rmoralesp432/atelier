# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: immersive.spec.ts >> opens a full-size scene, adds shapes without AI, and reuses meshes on selection
- Location: tests/immersive.spec.ts:5:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.boundingBox: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Send message' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "ATELIER home" [ref=e5] [cursor=pointer]:
      - /url: ./
    - button "Projects" [ref=e8] [cursor=pointer]:
      - generic [ref=e9]: Untitled study
    - button "Explore design" [ref=e10] [cursor=pointer]
  - main [ref=e14]:
    - region "Modeling workspace" [ref=e15]:
      - combobox "Camera view" [ref=e17]:
        - option "Perspective" [selected]
        - option "Orthographic"
        - option "Top view"
      - generic [ref=e18]:
        - button "Appearance" [ref=e19] [cursor=pointer]
        - generic "Project north":
          - generic: ↑
          - generic: Project N
        - generic "Interactive 3D modeling viewport" [ref=e24]
        - generic [ref=e25]:
          - generic "Object color" [ref=e26]:
            - textbox "Selected object color" [ref=e27] [cursor=pointer]: "#e2e7e6"
          - button "Edit selected dimensions" [ref=e28] [cursor=pointer]:
            - generic [ref=e29]: Volume 03
            - strong [ref=e30]: 8 × 8 × 8 m
          - button "Selected object actions" [ref=e31] [cursor=pointer]
        - toolbar "Modeling tools" [ref=e36]:
          - toolbar "Touch navigation" [ref=e37]:
            - button "Touch orbit" [pressed] [ref=e38] [cursor=pointer]
            - button "Touch pan" [ref=e42] [cursor=pointer]
            - button "Touch edit" [ref=e48] [cursor=pointer]
          - button "Frame all" [ref=e52] [cursor=pointer]
      - generic "Atelier voice companion" [ref=e59]:
        - button "Voice orb" [ref=e60] [cursor=pointer]
        - status [ref=e62]: Atelier
      - navigation "Workspace actions" [ref=e63]:
        - button "Show objects" [ref=e64] [cursor=pointer]:
          - generic [ref=e69]: Objects
        - button "Create a 3D shape" [ref=e70] [cursor=pointer]:
          - generic [ref=e72]: Create
        - button "Open chat" [ref=e73] [cursor=pointer]:
          - generic [ref=e76]: Chat
        - button "Design tools" [active] [ref=e77] [cursor=pointer]:
          - generic [ref=e81]: Tools
  - contentinfo:
    - generic: 3 volumes 1 selected
    - generic [ref=e82]:
      - button "Undo" [ref=e83] [cursor=pointer]
      - button "Redo" [disabled] [ref=e87]
```

# Test source

```ts
  1   | import { openTool } from './tools';
  2   | import { test, expect } from '@playwright/test';
  3   | import type { Operation } from '../src/intelligence/plan';
  4   | 
  5   | test('opens a full-size scene, adds shapes without AI, and reuses meshes on selection', async ({
  6   |   page,
  7   | }) => {
  8   |   // This covers a desktop workflow plus a viewport resize and mobile panels.
  9   |   // Software WebGL CI runners need more total time; assertions keep 5s limits.
  10  |   test.setTimeout(60000);
  11  |   const errors: string[] = [];
  12  |   page.on('pageerror', (e) => errors.push(e.message));
  13  |   await page.goto('/');
  14  |   await expect(page.getByTestId('viewport')).toHaveAttribute(
  15  |     'data-model-objects',
  16  |     '2',
  17  |   );
  18  |   await expect(page.locator('.objects-panel')).toBeHidden();
  19  |   await expect(page.locator('.inspector-panel')).toBeHidden();
  20  |   const canvas = await page.locator('canvas').boundingBox();
  21  |   expect(canvas!.width).toBeGreaterThan(1400);
  22  |   expect(canvas!.height).toBeGreaterThan(900);
  23  |   const builds = await page
  24  |     .getByTestId('viewport')
  25  |     .getAttribute('data-mesh-builds');
  26  |   await page.getByRole('button', { name: 'Show objects' }).click();
  27  |   await page.locator('.object-row').nth(1).click();
  28  |   await expect(page.locator('.selection-summary')).toContainText(
  29  |     'Vertical annex',
  30  |   );
  31  |   await expect(page.getByTestId('viewport')).toHaveAttribute(
  32  |     'data-mesh-builds',
  33  |     builds!,
  34  |   );
  35  |   await page.getByRole('button', { name: 'Hide objects' }).click();
  36  |   await expect(
  37  |     page.getByRole('button', { name: 'Add a shape', exact: true }),
  38  |   ).toHaveCount(0);
  39  |   await expect(
  40  |     page.getByRole('button', { name: 'Create floors and curtain wall' }),
  41  |   ).toBeHidden();
  42  |   await page.getByRole('button', { name: 'Show objects' }).click();
  43  |   await page.getByText('Manual tools', { exact: true }).click();
  44  |   await page.getByLabel('Primitive shape').selectOption('sphere');
  45  |   await page.getByRole('button', { name: 'Add shape', exact: true }).click();
  46  |   await page.getByRole('button', { name: 'Hide objects' }).click();
  47  |   await expect(page.getByTestId('viewport')).toHaveAttribute(
  48  |     'data-model-objects',
  49  |     '3',
  50  |   );
  51  |   await page.getByRole('button', { name: 'Edit selected dimensions' }).click();
  52  |   await expect(
  53  |     page.getByRole('spinbutton', { name: 'Height', exact: true }),
  54  |   ).toHaveValue('8');
  55  |   await openTool(page, 'Collapse inspector');
  56  |   await page.waitForTimeout(700);
  57  |   await page.screenshot({ path: 'test-results/atelier-immersive.png' });
  58  |   await page.setViewportSize({ width: 390, height: 844 });
  59  |   await page.getByRole('button', { name: 'Show objects' }).click();
  60  |   await expect(page.locator('.objects-panel')).toBeVisible();
  61  |   await page.getByRole('button', { name: 'Hide objects' }).click();
  62  |   await page.getByRole('button', { name: 'Design tools', exact: true }).click();
  63  |   await openTool(page, 'Expand inspector');
  64  |   await expect(page.locator('.inspector-panel')).toBeVisible();
  65  |   await page
  66  |     .getByRole('button', { name: 'Close inspector', exact: true })
  67  |     .click();
  68  |   await page.getByRole('button', { name: 'Design tools', exact: true }).click();
  69  |   for (const name of ['Import', 'Export project']) {
  70  |     const bounds = await page
  71  |       .getByRole('button', { name, exact: true })
  72  |       .boundingBox();
  73  |     expect(bounds!.x).toBeGreaterThanOrEqual(0);
  74  |     expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(390);
  75  |   }
  76  |   await page.getByRole('button', { name: 'Design tools', exact: true }).click();
  77  |   const send = (await page
  78  |     .getByRole('button', { name: 'Send message' })
> 79  |     .boundingBox())!;
      |      ^ Error: locator.boundingBox: Test timeout of 60000ms exceeded.
  80  |   expect(send.x + send.width).toBeLessThanOrEqual(390);
  81  |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(
  82  |     390,
  83  |   );
  84  |   await page.screenshot({ path: 'test-results/atelier-mobile-layout.png' });
  85  |   expect(errors).toEqual([]);
  86  | });
  87  | 
  88  | test('architectural workflow renders real floors/glass, preserves elevation and restores history (explicit model fixtures)', async ({
  89  |   page,
  90  | }) => {
  91  |   test.setTimeout(60000);
  92  |   let turn = 0;
  93  |   await page.route('**/api/config', (r) =>
  94  |     r.fulfill({
  95  |       json: { configured: true, authenticated: true, voiceConfigured: false },
  96  |     }),
  97  |   );
  98  |   await page.route('**/api/plan', (r) => {
  99  |     const body = r.request().postDataJSON();
  100 |     const upper = body.scene.objects.find(
  101 |       (v: any) => v.name === 'Floating pavilion',
  102 |     )?.id;
  103 |     const steps: Operation[][] = [
  104 |       [
  105 |         {
  106 |           type: 'create_at',
  107 |           name: 'Floating pavilion',
  108 |           shape: 'box',
  109 |           width: 100,
  110 |           depth: 20,
  111 |           height: 8,
  112 |           x: 0,
  113 |           y: 4,
  114 |           z: 0,
  115 |           rotation: 0,
  116 |         },
  117 |         {
  118 |           type: 'offset_base',
  119 |           target: '$name:Floating pavilion',
  120 |           offset: 3,
  121 |           height: 4,
  122 |           name: 'Lower pavilion',
  123 |         },
  124 |       ],
  125 |       [{ type: 'rotate', targets: [upper], degrees: 45, relative: true }],
  126 |       [
  127 |         {
  128 |           type: 'building',
  129 |           target: upper,
  130 |           floors: 2,
  131 |           slabThickness: 0.25,
  132 |           facade: true,
  133 |           panelWidth: 1.5,
  134 |           mullionWidth: 0.06,
  135 |         },
  136 |       ],
  137 |     ];
  138 |     if (turn === 3) {
  139 |       expect(body.pendingReview?.message).toContain('floor slabs');
  140 |       return r.fulfill({
  141 |         json: {
  142 |           intent: 'confirm',
  143 |           message: 'Apply the reviewed change.',
  144 |           operations: [],
  145 |         },
  146 |       });
  147 |     }
  148 |     return r.fulfill({
  149 |       json: {
  150 |         intent: 'apply',
  151 |         message: 'Two floor slabs and a roof, retaining the original envelope.',
  152 |         operations: steps[turn++],
  153 |       },
  154 |     });
  155 |   });
  156 |   await page.goto('/');
  157 |   await page.getByLabel('Import project file').setInputFiles({
  158 |     name: 'empty.json',
  159 |     mimeType: 'application/json',
  160 |     buffer: Buffer.from(
  161 |       JSON.stringify({ version: 2, volumes: [], selectedId: null }),
  162 |     ),
  163 |   });
  164 |   const say = async (text: string) => {
  165 |     await page.getByRole('textbox', { name: 'Message Atelier' }).fill(text);
  166 |     await page
  167 |       .getByRole('button', { name: 'Send message', exact: true })
  168 |       .click();
  169 |   };
  170 |   await say(
  171 |     'Create a 100 by 20 m volume, 8 m tall and raised 4 m, with a base offset outward 3 m on each side.',
  172 |   );
  173 |   await expect(page.getByTestId('viewport')).toHaveAttribute(
  174 |     'data-model-objects',
  175 |     '2',
  176 |   );
  177 |   await expect(page.locator('.selection-summary')).toContainText('Raised 4 m');
  178 |   await say('Rotate it 45 degrees.');
  179 |   await expect(page.getByRole('log')).toContainText('45°');
```