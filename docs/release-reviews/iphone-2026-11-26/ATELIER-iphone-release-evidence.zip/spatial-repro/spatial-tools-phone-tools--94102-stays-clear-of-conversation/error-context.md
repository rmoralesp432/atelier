# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: spatial-tools.spec.ts >> phone tools remain reachable and the placement instruction stays clear of conversation
- Location: tests/spatial-tools.spec.ts:255:1

# Error details

```
Test timeout of 90000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "ATELIER home" [ref=e5] [cursor=pointer]:
      - /url: ./
    - button "Projects" [ref=e8] [cursor=pointer]:
      - generic [ref=e9]: Untitled study
    - button "Explore design" [ref=e10] [cursor=pointer]
  - main [ref=e14]:
    - region "Modeling workspace" [ref=e15]:
      - combobox "Camera view" [ref=e17]:
        - option "Perspective" [selected]
        - option "Orthographic"
        - option "Top view"
      - generic [ref=e18]:
        - button "Appearance" [ref=e19] [cursor=pointer]
        - generic "Project north":
          - generic: ↑
          - generic: Project N
        - generic [ref=e23]:
          - generic "Interactive 3D modeling viewport" [ref=e24]
          - generic "Live face dimension": Height · 5.00 m
          - status:
            - strong: Pull a face to shape it
            - generic: Drag a luminous handle · opposite side stays fixed
            - generic: Curved and cut forms resize along the chosen axis.
        - generic [ref=e25]:
          - generic "Object color" [ref=e26]:
            - textbox "Selected object color" [ref=e27] [cursor=pointer]: "#e2e7e6"
          - button "Edit selected dimensions" [ref=e28] [cursor=pointer]:
            - generic [ref=e29]: Main pavilion
            - strong [ref=e30]: 14 × 9 × 5 m
          - button "Selected object actions" [expanded] [active] [ref=e31] [cursor=pointer]
        - toolbar "Modeling tools" [ref=e36]:
          - toolbar "Touch navigation" [ref=e37]:
            - button "Touch orbit" [ref=e38] [cursor=pointer]
            - button "Touch pan" [ref=e42] [cursor=pointer]
            - button "Touch edit" [pressed] [ref=e48] [cursor=pointer]
          - button "Select" [ref=e51] [cursor=pointer]
          - button "Move" [ref=e54] [cursor=pointer]
          - button "Rotate" [ref=e60] [cursor=pointer]
          - button "Push / pull" [pressed] [ref=e64] [cursor=pointer]
          - button "Frame all" [ref=e71] [cursor=pointer]
      - dialog "Selected object actions" [ref=e78]:
        - generic [ref=e79]:
          - generic [ref=e80]:
            - strong [ref=e81]: Main pavilion
            - generic [ref=e82]: Changes can be undone
          - button "Close object actions" [ref=e83] [cursor=pointer]
        - generic [ref=e87]:
          - button "Move" [ref=e88] [cursor=pointer]
          - button "Modify" [ref=e94] [cursor=pointer]
          - button "Duplicate" [ref=e100] [cursor=pointer]
          - button "Hide" [ref=e104] [cursor=pointer]
          - button "Select several" [ref=e110] [cursor=pointer]
          - button "Delete selection" [ref=e115] [cursor=pointer]: Delete
        - paragraph [ref=e119]: Tap to select · Hold for actions · Double-tap to focus
      - generic "Atelier voice companion" [ref=e120]:
        - button "Voice orb" [ref=e121] [cursor=pointer]
        - status [ref=e123]: Atelier
      - navigation "Workspace actions" [ref=e124]:
        - button "Show objects" [ref=e125] [cursor=pointer]:
          - generic [ref=e130]: Objects
        - button "Create a 3D shape" [ref=e131] [cursor=pointer]:
          - generic [ref=e133]: Create
        - button "Hide chat" [pressed] [ref=e134] [cursor=pointer]:
          - generic [ref=e137]: Chat
        - button "Design tools" [ref=e138] [cursor=pointer]:
          - generic [ref=e142]: Tools
      - generic [ref=e143]:
        - generic [ref=e144]:
          - button "Atelier Close conversation" [expanded] [ref=e145] [cursor=pointer]:
            - generic [ref=e148]: Conversation
          - button "Minimize conversation" [ref=e151] [cursor=pointer]
          - combobox "Conversation language" [ref=e154]:
            - option "English" [selected]
            - option "Spanish"
            - option "French"
            - option "German"
            - option "Italian"
            - option "Portuguese"
            - option "Japanese"
            - option "Chinese"
            - option "Arabic"
            - option "Korean"
            - option "Russian"
        - generic [ref=e155]:
          - strong [ref=e156]: What would you like to create?
          - button "Explore an editable sample house" [ref=e157] [cursor=pointer]
        - generic [ref=e161]:
          - textbox "Message Atelier" [ref=e162]:
            - /placeholder: Ask Atelier to create or change anything…
          - generic [ref=e163]:
            - button "Attach a reference photo" [ref=e164] [cursor=pointer]
            - button "Start voice conversation" [disabled] [ref=e166]
            - button "Send message" [disabled] [ref=e170]
  - contentinfo:
    - generic [ref=e173]:
      - button "Undo" [disabled] [ref=e174]
      - button "Redo" [disabled] [ref=e178]
```