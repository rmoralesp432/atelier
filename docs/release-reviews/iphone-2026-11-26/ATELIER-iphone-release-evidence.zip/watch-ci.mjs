import fs from 'node:fs';import {execFileSync} from 'node:child_process';
const id='45909790043', expected='93d936be54290e60922c15699a6877f97c0f5435';
const get=(path)=>JSON.parse(execFileSync('gh',['api',path],{encoding:'utf8'}));
let prior='';const deadline=Date.now()+30*60e3;
while(Date.now()<deadline){
 const run=get('repos/rmoralesp432/atelier/actions/runs/'+id);
 if(run.head_sha!==expected)throw Error('Unexpected CI commit');
 const jobs=get('repos/rmoralesp432/atelier/actions/runs/'+id+'/jobs').jobs;
 const summary={run:id,head:run.head_sha,status:run.status,conclusion:run.conclusion,jobs:jobs.map(j=>({name:j.name,status:j.status,conclusion:j.conclusion}))};
 fs.writeFileSync('.cloud/iphone-release/ci-final.json',JSON.stringify(summary,null,2));
 const current=JSON.stringify(summary);if(current!==prior){console.log(current);prior=current;}
 if(run.status==='completed')process.exit(run.conclusion==='success'?0:1);
 await new Promise(r=>setTimeout(r,30000));
}
throw Error('CI wait deadline reached; no merge performed');
