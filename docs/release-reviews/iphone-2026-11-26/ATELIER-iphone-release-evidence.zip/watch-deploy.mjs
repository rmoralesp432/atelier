import fs from 'node:fs';
import assert from 'node:assert/strict';
const folder='.cloud/iphone-release';
const start=JSON.parse(fs.readFileSync(folder+'/deploy-start.json','utf8'));
assert(start.id&&start.expectedCommit);
const endpoint=`https://api.render.com/v1/services/srv-db7vilu89jmc73dh9d40/deploys/${start.id}`;
const headers={Authorization:`Bearer ${process.env.ATELIER_RENDER_API_KEY}`};
const deadline=Date.now()+20*60e3;
let previous='';
while(Date.now()<deadline){
 const r=await fetch(endpoint,{headers,signal:AbortSignal.timeout(25000)});
 if(!r.ok)throw Error(`Render deployment lookup returned ${r.status}`);
 const d=await r.json();
 const summary={checkedAt:new Date().toISOString(),id:d.id,status:d.status,commit:d.commit?.id,expectedCommit:start.expectedCommit,createdAt:d.createdAt,updatedAt:d.updatedAt,finishedAt:d.finishedAt};
 fs.writeFileSync(folder+'/deployment.json',JSON.stringify(summary,null,2));
 fs.appendFileSync(folder+'/deployment-timeline.jsonl',JSON.stringify(summary)+'\n');
 if(summary.status!==previous){console.log(JSON.stringify(summary));previous=summary.status;}
 if(d.status==='live'){assert.equal(d.commit?.id,start.expectedCommit);process.exit(0);}
 if(['build_failed','update_failed','canceled','deactivated'].includes(d.status))throw Error(`Render deployment stopped: ${d.status}`);
 await new Promise(resolve=>setTimeout(resolve,15000));
}
throw Error('Render deadline exceeded; inspect saved deployment state');
