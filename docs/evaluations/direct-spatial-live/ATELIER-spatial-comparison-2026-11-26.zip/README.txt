Open direct-spatial-live/REPORT.md for the human-readable comparison. Raw API evidence, measurements, projects, and frozen application diff are included. No merge or deployment was performed.
