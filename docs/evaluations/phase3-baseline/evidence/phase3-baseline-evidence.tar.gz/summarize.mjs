// Read-only analysis of preserved baseline evidence. No API calls.
import fs from 'node:fs';
import { join } from 'node:path';
const root = '.cloud/phase3-baseline', dir = join(root, 'live');
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const results = read(join(dir, 'results.json')), ledger = read(join(dir, 'ledger.json'));
const sum = (xs, key) => xs.reduce((n, x) => n + (x[key] ?? 0), 0);
const cases = results.map(t => {
  const calls = ledger.calls.filter(c => c.caseId === t.id);
  const host = t.hostReplay ?? t.hostReport;
  const events = t.events ?? [];
  const path = join(dir, `${t.id}-before.json`), afterPath = join(dir, `${t.id}-after.json`);
  const before = fs.existsSync(path) ? read(path) : null, after = fs.existsSync(afterPath) ? read(afterPath) : null;
  return {
    id: t.id, status: t.status, diagnostic: !!t.diagnostic,
    committed: t.committed ?? null, elapsedSeconds: t.elapsedMs / 1000,
    calls: calls.length, estimatedUsd: sum(calls, 'estimatedUsd'),
    conservativeUsd: calls.reduce((n,c)=>n+(c.chargedUsd??c.reservedUsd),0),
    executorApiSeconds: sum(calls.filter(c => c.role === 'executor'), 'elapsedMs') / 1000,
    reviewerApiSeconds: sum(calls.filter(c => c.role === 'reviewer'), 'elapsedMs') / 1000,
    hostStatus: host?.status, hostCanCommit: host?.canCommit,
    externalCounts: (t.facts ?? []).reduce((a,c)=>(a[c.status]=(a[c.status]??0)+1,a),{}),
    failedExternalChecks: t.facts?.filter(f=>f.status!=='verified'),
    hostCounts: (host?.checks ?? []).reduce((a,c)=>(a[c.outcome]=(a[c.outcome]??0)+1,a),{}),
    hostLimits: [...(host?.checks?.filter(c=>c.outcome!=='verified').map(c=>c.observed)??[]), ...(host?.qualitativeLimits??[])],
    toolOrVerificationFeedback: events.filter(e=>e.input?.validationFeedback).map(e=>({error:e.input.validationFeedback.error,failedChecks:e.input.validationFeedback.verification?.checks?.filter(c=>c.outcome==='incorrect')})),
    operationsProposed: events.filter(e=>e.kind==='executor').flatMap(e=>e.response?.operations?.map(o=>o.type)??[]),
    executorIntents: events.filter(e=>e.kind==='executor').map(e=>e.response?.intent),
    originalObjects: before?.project.volumes.length, finalObjects: after?.project.volumes.length,
    createdIds: after?.project.volumes.filter(v=>!before.project.volumes.some(o=>o.id===v.id)).map(v=>v.id),
    changedOriginalIds: after?.project.volumes.filter(v=>{const old=before.project.volumes.find(o=>o.id===v.id);return old && JSON.stringify(old)!==JSON.stringify(v);}).map(v=>v.id),
    transaction: t.transaction ?? t.transactionEvidence,
    error: t.error, serious: t.serious,
  };
});
const report = {
  source: 'Derived read-only from immutable live records; scoring is not changed.',
  calls: ledger.calls.length, estimatedUsd: sum(ledger.calls, 'estimatedUsd'),
  conservativeUsd: ledger.calls.reduce((n,c)=>n+(c.chargedUsd??c.reservedUsd),0),
  unknownCalls: ledger.calls.filter(c=>c.outcome!=='usage-reconciled').length,
  inputTokens: sum(ledger.calls,'inputTokens'), outputTokens:sum(ledger.calls,'outputTokens'), reasoningTokens:sum(ledger.calls,'reasoningTokens'),
  modelIds: [...new Set(ledger.calls.map(c=>c.modelReturned))], serviceTiers: [...new Set(ledger.calls.map(c=>c.serviceTier))],
  executorApiSeconds:sum(ledger.calls.filter(c=>c.role==='executor'),'elapsedMs')/1000,
  reviewerApiSeconds:sum(ledger.calls.filter(c=>c.role==='reviewer'),'elapsedMs')/1000,
  maximumInputTokens:Math.max(...ledger.calls.map(c=>c.inputTokens??0)),
  cases,
};
fs.writeFileSync(join(root, 'analysis.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,cases:cases.map(({toolOrVerificationFeedback,hostLimits,operationsProposed,createdIds,changedOriginalIds,...t})=>t)},null,2));
