/** Offline evidence rendering only. No provider, API key, or generation calls. */
import { readFileSync, writeFileSync, mkdirSync, existsSync, realpathSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { chromium } from '@playwright/test';
import { createServer } from 'vite';

const root = '.cloud/phase3-baseline';
const live = join(root, 'live');
const out = join(root, 'visual-review');
mkdirSync(out, { recursive: true });
const results = JSON.parse(readFileSync(join(live, 'results.json'), 'utf8'));
const vite = await createServer({ server: { host: '127.0.0.1', port: 0, fs: { allow: [resolve('.'), realpathSync('node_modules')] } }, appType: 'custom' });
await vite.listen();
const origin = `http://127.0.0.1:${(vite.httpServer!.address() as any).port}`;
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
try {
  const page = await browser.newPage();
  await page.route('**/*', route => {
    const url = route.request().url();
    if (url === origin + '/__evidence') return route.fulfill({ contentType: 'text/html', body: '<!doctype html><title>Offline geometry evidence</title>' });
    if (url.startsWith(origin + '/') || /^(data|blob):/.test(url)) return route.continue();
    return route.abort();
  });
  await page.goto(origin + '/__evidence');
  await page.evaluate(async () => {
    const kp = '/src/geometry/kernel.ts', wp = '/node_modules/manifold-3d/manifold.wasm?url';
    const k = await import(kp), w = await import(wp);
    k.setKernelWasmUrl(w.default);
  });
  const manifest: any[] = [];
  for (const t of results) {
    const afterPath = join(live, `${t.id}-after.json`);
    if (!t.committed || !existsSync(afterPath)) continue;
    const s = JSON.parse(readFileSync(afterPath, 'utf8'));
    const first = t.id.replace('diagnostic-', '')[0] + '1';
    const original = JSON.parse(readFileSync(join(live, `${first}-before.json`), 'utf8'));
    const old = new Set(original.project.volumes.map((v: any) => v.id));
    const project = { ...s.project, volumes: s.project.volumes.filter((v: any) => !old.has(v.id)) };
    const observation = await page.evaluate(async project => {
      const p = '/src/intelligence/renderObservation.ts';
      return (await import(p)).renderObservation(project);
    }, project);
    const files: string[] = [];
    for (const [i, view] of observation.views.entries()) {
      const name = `${t.id}-${i}.jpg`;
      writeFileSync(join(out, name), Buffer.from(view.image.split(',')[1], 'base64'));
      files.push(name);
    }
    manifest.push({ id: t.id, source: afterPath, status: observation.status, note: observation.note, includedIds: project.volumes.map((v: any) => v.id), excludedIds: [...old], files, purpose: 'Offline qualitative review of actual final geometry, focused on task components. Full application screenshots retained separately. No paid calls.' });
    console.log(`${t.id}: ${observation.status}, ${files.length} views`);
  }
  writeFileSync(join(out, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
} finally {
  await browser.close();
  await vite.close();
}
