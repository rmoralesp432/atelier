import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {chromium,expect} from '@playwright/test';
import {serializeSession,parseSession} from '../../src/intelligence/engine.ts';
import {assertReplayScene,replayResponse} from '../../scripts/release-evaluation/replay.ts';
const folder='.cloud/criteria-hotfix/live/';
const read=(name:string)=>JSON.parse(readFileSync(folder+name,'utf8'));
const original=read('original.json'), models=read('model-results.json'), reviews=read('review-results.json'), manifest=read('manifest.json');
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1200,height:850},reducedMotion:'reduce'});
let model=0,review=0;const errors:string[]=[];
page.on('pageerror',e=>errors.push(e.message));
const session=()=>page.evaluate(()=>localStorage.getItem('atelier.session.v2')).then(s=>parseSession(s!));
try {
  await page.addInitScript((serialized:string)=>{
    localStorage.setItem('atelier.start-direct','true');
    if(!localStorage.getItem('atelier.session.v2'))localStorage.setItem('atelier.session.v2',serialized);
  },serializeSession(original));
  await page.route('**/api/**',r=>r.abort());
  await page.route('**/api/config',r=>r.fulfill({json:{configured:true,authenticated:true,agentConfigured:true,voiceConfigured:false}}));
  await page.route('**/api/plan',async r=>{
    const saved=models[model++];assert(saved,'No invented continuation');
    const actual=r.request().postDataJSON();
    const result=replayResponse(saved.input,actual,saved.result);
    await r.fulfill({json:result});
  });
  await page.route('**/api/completion-criteria',async r=>{
    const saved=reviews[review++];assert(saved,'No invented review');
    const actual=r.request().postDataJSON();
    assertReplayScene(saved.input,actual);
    assert(saved.result.checks.every((c:any)=>!JSON.stringify(c.requirement).includes('30e7d5e7-')),'Review must use retained semantic selectors, not stale regenerated IDs');
    await r.fulfill({json:saved.result});
  });
  await page.goto('http://127.0.0.1:4173');
  await expect(page.getByTestId('viewport')).toHaveAttribute('data-model-objects','2',{timeout:30000});
  await page.getByRole('textbox',{name:'Message Atelier'}).fill(manifest.prompt);
  await page.getByRole('button',{name:'Send message',exact:true}).click();
  await expect.poll(async()=>(await session()).project.volumes.length,{timeout:60000}).toBe(5);
  const committed=await session();assert.deepEqual(committed.project.volumes.slice(0,2),original.project.volumes);
  assert.equal(committed.past.length,original.past.length+1);
  assert.equal(model,models.length);assert.equal(review,reviews.length);
  await page.reload();await expect(page.getByTestId('viewport')).toHaveAttribute('data-model-objects','5',{timeout:30000});
  assert.deepEqual((await session()).project,committed.project);
  await page.getByRole('button',{name:'Undo',exact:true}).click();await expect.poll(async()=>(await session()).project,{timeout:30000}).toEqual(original.project);
  await page.getByRole('button',{name:'Redo',exact:true}).click();await expect.poll(async()=>(await session()).project,{timeout:30000}).toEqual(committed.project);
  assert.deepEqual(errors,[]);
  writeFileSync('.cloud/criteria-hotfix/final-browser-replay.json',JSON.stringify({status:'PASS',provenance:'Exact previously paid real-AI plans and independent criteria, replayed offline on final source after scene-equivalence checks. No new AI reasoning or paid calls.',modelResponses:model,reviewResponses:review,commit:true,persistence:true,reload:true,undoRedo:true,errors,committed},null,2));
  console.log('Final-source browser replay passed; scene bindings, commit, reload and Undo/Redo verified. Zero paid calls.');
} finally {await browser.close();}
